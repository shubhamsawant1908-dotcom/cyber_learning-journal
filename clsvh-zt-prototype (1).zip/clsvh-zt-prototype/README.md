# CLSVH-ZT Single-File Prototype

This repository contains the complete CLSVH-ZT research prototype in one file: `clsvh_zt.py`.

CLSVH-ZT models a zero-trust request header that is signed, validated, and
re-signed as it passes through a chain of trusted components (e.g. WAF →
Firewall → Service), accumulating a hash-linked audit trail and a trust score
along the way.

## Features

- Ed25519 signatures and key identifiers.
- Expiring, nonce-bound request headers.
- Replay-cache protection, checked once at ingress.
- Hash-linked validation lineage (tamper-evident audit trail).
- Fast, slow, and block policy decisions.
- Sensitive resources (`payments`, `identity`, `admin`) always take the slow path, regardless of trust level.

## Fixed in this version

The original `simulate_secure_flow()` demo passed `index == 0` as the
`replay_free` flag inside the validation loop, so replay protection was only
satisfied for the first component (WAF) and evaluated as `False` for every
later hop. Since a single request legitimately passes through multiple
internal components, this made the demo misclassify normal forwarding as a
replay attack — every run ended in `Decision: block / replay_detected`.

The fix anchors replay protection to the client's original `(request_id,
nonce)` pair via `ReplayCache`, checked once at ingress, instead of
re-checking it at every internal hop. The demo now correctly reaches
`Decision: allow_fast` with a full `WAF → Firewall → Service` lineage. A
genuine replay (the same `request_id`/`nonce` submitted twice from outside)
is still correctly rejected — see the CI workflow and self-tests.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
python clsvh_zt.py        # runs the demo secure flow
python clsvh_zt.py test   # runs the built-in self-tests
```

Expected demo output:

```
=== Secure CLSVH-ZT Demo ===
Decision: allow_fast
Trust level: 3
Lineage events: 4
- client: created
- WAF: ok
- Firewall: ok
- Service: ok
```

## Testing

Two layers of tests are included:

- `python clsvh_zt.py test` — fast built-in smoke test (no extra dependencies).
- `pytest` — a full suite in `tests/test_clsvh_zt.py` covering signature
  verification, header expiry/freshness, replay-cache behavior, every policy
  branch (invalid signature, replay, expired, stale, high risk, sensitive
  resource, fast path, default slow path), validator trust promotion/
  downgrade, and an end-to-end regression test for the replay-detection bug
  described above.

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

## VS Code

Open this folder in Visual Studio Code, select the `.venv` Python interpreter, and run `clsvh_zt.py` using the Run button or integrated terminal.

## Continuous integration

A GitHub Actions workflow (`.github/workflows/ci.yml`) runs the self-tests
and the demo on every push and pull request against Python 3.11 and 3.12,
and fails the build if the demo ever blocks — this is what would have
caught the bug above automatically.

## GitHub

```bash
git init
git add .
git commit -m "Fix replay-detection bug in demo flow; add LICENSE and CI"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/clsvh-zt-prototype.git
git push -u origin main
```

## Contact

Email: [shubhamsawant1908@gmail.com](mailto:shubhamsawant1908@gmail.com)

No LinkedIn account is listed.

## Security notice

This is a research prototype. Do not use `trust_level` alone for
authorization or to disable inspection. Production deployment requires
secure key management, key rotation, identity verification, distributed
replay protection, centralized policy, revocation, and independent security
review.

## License

MIT — see [LICENSE](LICENSE).
