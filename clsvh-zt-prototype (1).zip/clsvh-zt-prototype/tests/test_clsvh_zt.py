"""Pytest coverage for clsvh_zt.py.

Run with: pytest -q
"""
import pytest

from clsvh_zt import (
    CLSVHHeader,
    CLSVHValidator,
    PolicyDecision,
    ReplayCache,
    SigningKeyPair,
    evaluate_policy,
    load_public_key,
    simulate_secure_flow,
    verify_signature,
)


# --- signing -----------------------------------------------------------

def test_sign_and_verify_roundtrip():
    keys = SigningKeyPair.generate("k1")
    signature = keys.sign(b"payload")
    assert verify_signature(keys.public_key, b"payload", signature)


def test_verify_rejects_tampered_payload():
    keys = SigningKeyPair.generate("k1")
    signature = keys.sign(b"payload")
    assert not verify_signature(keys.public_key, b"different-payload", signature)


def test_verify_rejects_garbage_signature():
    keys = SigningKeyPair.generate("k1")
    assert not verify_signature(keys.public_key, b"payload", "not-a-real-signature")


def test_load_public_key_roundtrip():
    keys = SigningKeyPair.generate("k1")
    reloaded = load_public_key(keys.public_key_text())
    signature = keys.sign(b"payload")
    assert verify_signature(reloaded, b"payload", signature)


# --- header lifecycle ----------------------------------------------------

def test_create_rejects_bad_path_hint():
    with pytest.raises(ValueError):
        CLSVHHeader.create("u", "s", "orders", "read", "client", "key", path_hint="medium")


def test_create_rejects_non_positive_ttl():
    with pytest.raises(ValueError):
        CLSVHHeader.create("u", "s", "orders", "read", "client", "key", ttl_seconds=0)


def test_header_expires_after_ttl():
    header = CLSVHHeader.create("u", "s", "orders", "read", "client", "key", ttl_seconds=10)
    assert not header.is_expired(now=header.issued_at + 5)
    assert header.is_expired(now=header.issued_at + 10)


def test_lineage_is_hash_linked():
    header = CLSVHHeader.create("u", "s", "orders", "read", "client", "key")
    header.add_event("WAF", "ok", 1)
    header.add_event("Firewall", "ok", 1)
    assert header.lineage[0].previous_hash == "GENESIS"
    assert header.lineage[1].previous_hash == header.lineage[0].event_hash


def test_payload_changes_when_mutable_fields_change():
    header = CLSVHHeader.create("u", "s", "orders", "read", "client", "key")
    before = header.payload()
    header.trust_level = 3
    assert header.payload() != before


# --- replay cache --------------------------------------------------------

def test_replay_cache_blocks_second_consume_of_same_pair():
    cache = ReplayCache()
    assert cache.consume("req-1", "nonce-1") is True
    assert cache.consume("req-1", "nonce-1") is False


def test_replay_cache_allows_different_pairs():
    cache = ReplayCache()
    assert cache.consume("req-1", "nonce-1") is True
    assert cache.consume("req-1", "nonce-2") is True
    assert cache.consume("req-2", "nonce-1") is True


# --- policy evaluation -----------------------------------------------------

def _fresh_header(resource="orders", path_hint="fast", trust_level=0):
    header = CLSVHHeader.create("u", "s", resource, "read", "client", "key", path_hint=path_hint)
    header.trust_level = trust_level
    return header


def test_invalid_signature_blocks():
    header = _fresh_header()
    decision = evaluate_policy(header, signature_valid=False, replay_free=True)
    assert decision == PolicyDecision("block", "invalid_signature")


def test_replay_detected_blocks():
    header = _fresh_header()
    decision = evaluate_policy(header, signature_valid=True, replay_free=False)
    assert decision == PolicyDecision("block", "replay_detected")


def test_expired_header_blocks():
    header = CLSVHHeader.create("u", "s", "orders", "read", "client", "key", ttl_seconds=1)
    header.expires_at = header.issued_at - 1  # force expiry
    decision = evaluate_policy(header, signature_valid=True, replay_free=True)
    assert decision == PolicyDecision("block", "expired_header")


def test_stale_header_blocks():
    header = _fresh_header()
    header.issued_at -= 3600  # issued an hour ago, older than the freshness window
    decision = evaluate_policy(header, signature_valid=True, replay_free=True)
    assert decision == PolicyDecision("block", "stale_header")


def test_invalid_risk_score_blocks():
    header = _fresh_header()
    decision = evaluate_policy(header, signature_valid=True, replay_free=True, risk_score=150)
    assert decision == PolicyDecision("block", "invalid_risk_score")


def test_high_risk_blocks():
    header = _fresh_header()
    decision = evaluate_policy(header, signature_valid=True, replay_free=True, risk_score=70)
    assert decision == PolicyDecision("block", "high_risk")


@pytest.mark.parametrize("resource", ["payments", "identity", "admin"])
def test_sensitive_resource_always_slow_even_with_high_trust_and_fast_hint(resource):
    header = _fresh_header(resource=resource, path_hint="fast", trust_level=3)
    decision = evaluate_policy(header, signature_valid=True, replay_free=True)
    assert decision == PolicyDecision("allow_slow", "sensitive_resource")


def test_fast_path_requires_trust_and_fast_hint():
    header = _fresh_header(resource="orders", path_hint="fast", trust_level=2)
    decision = evaluate_policy(header, signature_valid=True, replay_free=True)
    assert decision == PolicyDecision("allow_fast", "validated_fast_path")


def test_low_trust_falls_back_to_slow_path():
    header = _fresh_header(resource="orders", path_hint="fast", trust_level=1)
    decision = evaluate_policy(header, signature_valid=True, replay_free=True)
    assert decision == PolicyDecision("allow_slow", "additional_validation_required")


# --- validator -------------------------------------------------------------

def test_validator_rejects_unknown_key_id():
    keys = SigningKeyPair.generate("k1")
    header = _fresh_header()
    header.key_id = "unknown-key"
    header.signature = keys.sign(header.payload())
    validator = CLSVHValidator("WAF", keys, trusted_public_keys={})
    assert validator.validate_signature(header) is False


def test_validator_downgrades_trust_and_blocks_on_zero_checks_passed():
    keys = SigningKeyPair.generate("waf-key")
    header = _fresh_header(trust_level=2)
    validator = CLSVHValidator("WAF", keys, trusted_public_keys={keys.key_id: keys.public_key_text()})
    result = validator.validate(header, checks_passed=0, decision=PolicyDecision("allow_slow", "ok"))
    assert result == PolicyDecision("block", "component_validation_failed")
    assert header.trust_level == 1
    assert header.lineage[-1].result == "checks_failed"


def test_validator_promotes_trust_and_resigns_on_success():
    keys = SigningKeyPair.generate("waf-key")
    header = _fresh_header(trust_level=0)
    validator = CLSVHValidator("WAF", keys, trusted_public_keys={keys.key_id: keys.public_key_text()})
    result = validator.validate(header, checks_passed=1, decision=PolicyDecision("allow_slow", "ok"))
    assert result == PolicyDecision("allow_slow", "ok")
    assert header.trust_level == 1
    assert header.issuer == "WAF"
    assert header.key_id == keys.key_id
    assert verify_signature(keys.public_key, header.payload(), header.signature)


# --- end-to-end demo flow ---------------------------------------------------

def test_simulate_secure_flow_reaches_allow_fast():
    """Regression test for the replay_free=index==0 bug: a legitimate multi-hop
    request must not be misclassified as a replay on the second hop."""
    header, decision = simulate_secure_flow()
    assert decision == "allow_fast"
    assert header.trust_level == 3
    assert [e.component for e in header.lineage] == ["client", "WAF", "Firewall", "Service"]
    assert all(e.result == "ok" for e in header.lineage[1:])
